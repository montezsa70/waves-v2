package dev.lelonio.square.data

import android.content.Context
import android.net.ConnectivityManager
import android.os.PowerManager
import coil.imageLoader
import coil.request.CachePolicy
import coil.request.ImageRequest
import coil.size.Scale
import dev.lelonio.square.playback.OfflineMode
import dev.lelonio.square.ui.components.spotifyLargeUrl
import dev.lelonio.square.ui.components.spotifyResizedUrl
import dev.lelonio.square.ui.theme.warmArtworkColor
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit

/**
 * Fetches the covers of the songs that are coming, before anyone asks for them.
 *
 * What a listener notices is not the download — a cover is a few dozen
 * kilobytes — but the chain behind it, all of it started at the moment the song
 * changes: the request, the wait for the server, the decode of a picture
 * sixteen hundred pixels across, and the colour read off it for the page. This
 * does that chain early, for a window of songs rather than for the next one,
 * and in two depths:
 *
 *  - **Everything in the window** is downloaded to the disk cache, at the two
 *    sizes the app draws a cover at (a row's thumbnail and the full print). The
 *    bytes are what takes the network; once they are on the disk, any size
 *    anyone asks for later is a local read.
 *  - **The first few** are also decoded into memory at the size the player
 *    uses, and their colour is worked out, so the song change is a cut to a
 *    picture already in hand rather than a load.
 *
 * Kept deliberately polite: two requests at a time so the audio's own buffering
 * is never starved, a smaller window on a metered connection or in battery
 * saver, nothing at all offline, and a restart from the top whenever the queue
 * changes so what is fetched first is always what is nearest.
 */
class ArtworkPrefetcher(context: Context) {

    private val app = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null

    /** Addresses already done, so a queue that changes ten times fetches once. */
    private val done = object : LinkedHashSet<String>() {
        override fun add(element: String): Boolean {
            val added = super.add(element)
            if (size > REMEMBERED) remove(first())
            return added
        }
    }

    private val gate = Semaphore(PARALLEL)

    /**
     * Replaces the window with [covers], nearest song first.
     *
     * Cheap to call as often as the queue changes: it cancels whatever was in
     * flight and starts again, and anything already fetched is skipped.
     */
    fun upcoming(covers: List<String>) {
        job?.cancel()
        if (OfflineMode.active.value) return
        val wanted = covers
            .filter(::fetchable)
            .distinct()
            .take(windowSize())
        if (wanted.isEmpty()) return

        job = scope.launch {
            coroutineScope {
                wanted.forEachIndexed { index, url ->
                    launch {
                        gate.withPermit {
                            // Only the nearest few are worth the memory of a
                            // decoded print and the work of reading a colour.
                            warm(url, deep = index < DEEP)
                        }
                    }
                }
            }
        }
    }

    private suspend fun warm(url: String, deep: Boolean) {
        val key = (if (deep) "deep:" else "disk:") + url
        synchronized(done) { if (key in done) return }

        val loader = app.imageLoader
        val density = app.resources.displayMetrics

        // The bytes, at the two sizes the app asks the CDN for. Not decoded
        // into memory: the disk cache is what is wanted, and a decode of a
        // sixty-four pixel copy costs nothing.
        val thumb = spotifyResizedUrl(url, THUMB_PX)
        // The full print is the one the player will ask for, which is not the
        // address a row uses: warming the row's copy twice would leave the
        // player's to be fetched in front of the listener.
        val large = spotifyLargeUrl(url)
        listOf(thumb, large).distinct().forEach { address ->
            runCatching {
                loader.execute(
                    ImageRequest.Builder(app)
                        .data(address)
                        .size(THUMB_PX)
                        .memoryCachePolicy(CachePolicy.DISABLED)
                        .diskCachePolicy(CachePolicy.ENABLED)
                        .networkCachePolicy(CachePolicy.ENABLED)
                        .build(),
                )
            }
        }

        if (deep) {
            // At the size the player draws the cover: full width at three by
            // four. Coil files a decode under the size it was made at, so a
            // copy read at any other size is not the one the screen will want.
            val width = density.widthPixels
            val height = width * 4 / 3
            runCatching {
                loader.execute(
                    ImageRequest.Builder(app)
                        .data(large)
                        .size(width, height)
                        .scale(Scale.FILL)
                        .build(),
                )
            }
            // And the colour the page takes from it, a second read of the same
            // file; see warmArtworkColor.
            runCatching { warmArtworkColor(app, url) }
        }

        // Only if it ran to the end: a fetch cut short by a changed queue must
        // not be remembered as done, or it would never be made.
        currentCoroutineContext().ensureActive()
        synchronized(done) { done.add(key) }
    }

    /** A remote address worth fetching: not a file, not one of the drawn tiles. */
    private fun fetchable(url: String): Boolean =
        url.isNotBlank() &&
            (url.startsWith("http://") || url.startsWith("https://"))

    /** How far ahead to look, given what the connection and the battery allow. */
    private fun windowSize(): Int {
        val cm = app.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        val power = app.getSystemService(Context.POWER_SERVICE) as? PowerManager
        return when {
            power?.isPowerSaveMode == true -> SAVER_WINDOW
            cm?.isActiveNetworkMetered == true -> METERED_WINDOW
            else -> WINDOW
        }
    }

    private companion object {
        /** Songs ahead on an ordinary connection. */
        const val WINDOW = 10

        /** On a metered connection, where somebody pays for the bytes. */
        const val METERED_WINDOW = 3

        /** In battery saver, where the radio is the thing to spare. */
        const val SAVER_WINDOW = 2

        /** How many of those get the full treatment: decode and colour. */
        const val DEEP = 3

        /** Requests at once. Two leaves the audio's own buffering its share. */
        const val PARALLEL = 2

        /** The thumbnail size the app asks the CDN for in rows and the mini player. */
        const val THUMB_PX = 300

        /** Addresses remembered as done. */
        const val REMEMBERED = 300
    }
}
