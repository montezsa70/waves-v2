package dev.lelonio.square.ui.glass

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.PressInteraction
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.isSpecified
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.addOutline
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.lerp
import dev.lelonio.square.ui.components.LocalCoverPalette
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.hypot
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawOutline
import androidx.compose.ui.graphics.graphicsLayer

/**
 * A tap that the element answers itself, with a ring of water from the finger.
 *
 * Material's ripple fills the whole hit area with the theme's colour, which is
 * wrong here twice over: the covers are pictures rather than surfaces, and the
 * shape it fills is the layout box rather than the rounded tile the user sees.
 *
 * What answers a touch here is three small things, all at once and all from
 * where the finger landed:
 *  - the element gives a little under the finger and springs back;
 *  - a soft ring of light spreads out from the touch point, thin and fading, in
 *    a tint taken from the cover that is playing, clipped to the element's own
 *    shape — water, not a wash of colour over the artwork;
 *  - the tap itself is delivered a beat later ([feedbackDelayMs]), so the
 *    ring has begun before the screen moves. Short enough never to feel slow,
 *    long enough that a tap is seen to have landed.
 *
 * Rows, which are mostly empty space and where a shrink alone reads as a
 * wobble, can pass a [shape] and get a soft tint inside it as well.
 */
@Composable
fun Modifier.pressable(
    onClick: () -> Unit,
    /** When set, the row is tinted inside this shape while held. */
    shape: Shape? = null,
    /** How far it gives. Small tiles want less than a full-width card. */
    pressedScale: Float = 0.96f,
    onLongClick: (() -> Unit)? = null,
    enabled: Boolean = true,
    /**
     * How long after the finger lifts the tap is delivered. Zero for something
     * that has to answer at once, such as a control that is already the answer.
     */
    feedbackDelayMs: Long = TAP_FEEDBACK_MS,
    /** Whether the ring is drawn; off for the few things that carry their own. */
    ring: Boolean = true,
): Modifier {
    val interaction = remember { MutableInteractionSource() }
    val scope = rememberCoroutineScope()
    val latestClick by rememberUpdatedState(onClick)
    val accent = LocalCoverPalette.current.firstOrNull()
    // White carrying some of the cover's colour, so the ring belongs to the
    // music playing and is still light enough to read on any picture.
    val tintColor = if (accent == null) Color.White else lerp(Color.White, accent, 0.45f)

    // Where the finger landed, and how far the ring has travelled: 0 as it
    // leaves, 1 when it is gone, which is also how it rests.
    var origin by remember { mutableStateOf(Offset.Unspecified) }
    val ringProgress = remember { Animatable(1f) }

    // Read as a stream of presses and releases rather than as a "held" flag.
    //
    // A flag gives no way to tell a tap from an element that has simply never
    // been touched, and no time to play anything: a tap is over in a few dozen
    // milliseconds, so an animation that turns round the moment the flag drops
    // never gets far enough down to be seen. Only a deliberate hold showed
    // anything, and answering the flag's initial value animated everything on
    // screen at once as it scrolled in.
    //
    // Handled one event at a time, so the dip is always finished before it is
    // undone: the release waits its turn while the element goes down, and
    // whatever the finger did, what is seen is a full press and a release.
    val scale = remember { Animatable(1f) }
    LaunchedEffect(interaction, enabled, pressedScale, ring) {
        interaction.interactions.collect { event ->
            when (event) {
                is PressInteraction.Press -> if (enabled) {
                    if (ring) {
                        origin = event.pressPosition
                        // On its own clock: the dip is over in ninety
                        // milliseconds and the ring takes four times that.
                        launch {
                            ringProgress.snapTo(0f)
                            ringProgress.animateTo(1f, tween(RING_MS, easing = FastOutSlowInEasing))
                        }
                    }
                    scale.animateTo(pressedScale, tween(90, easing = FastOutSlowInEasing))
                }

                is PressInteraction.Release, is PressInteraction.Cancel -> {
                    // Softly damped rather than bouncy on the way back: this
                    // fires dozens of times a session, and an overshoot that
                    // reads as lively on the first tap reads as loose by the
                    // tenth.
                    scale.animateTo(
                        1f,
                        spring(
                            dampingRatio = Spring.DampingRatioNoBouncy,
                            stiffness = Spring.StiffnessMediumLow,
                        ),
                    )
                }
            }
        }
    }

    // Tied to the dip instead of animated on its own, so the two cannot come
    // apart on a fast tap.
    val travel = (1f - pressedScale).coerceAtLeast(0.0001f)
    val tint = ((1f - scale.value) / travel).coerceIn(0f, 1f) * 0.10f

    return this
        .graphicsLayer {
            scaleX = scale.value
            scaleY = scale.value
        }
        .then(
            if (shape == null && !ring) {
                Modifier
            } else {
                Modifier.drawWithContent {
                    drawContent()
                    if (shape != null && tint > 0f) {
                        drawOutline(
                            outline = shape.createOutline(size, layoutDirection, this),
                            color = Color.White.copy(alpha = tint),
                        )
                    }
                    val t = ringProgress.value
                    val o = origin
                    if (ring && t < 1f && o.isSpecified) {
                        drawRing(o, t, tintColor, shape)
                    }
                }
            },
        )
        .combinedClickable(
            interactionSource = interaction,
            // The press animation is the indication. Leaving the default here
            // would draw the ripple on top of it.
            indication = null,
            enabled = enabled,
            onLongClick = onLongClick,
            onClick = {
                if (feedbackDelayMs <= 0L) {
                    latestClick()
                } else {
                    scope.launch {
                        delay(feedbackDelayMs)
                        latestClick()
                    }
                }
            },
        )
}

/**
 * One ring, [t] of the way out from [origin].
 *
 * A band of light between two soft edges rather than a drawn circle, so there
 * is no outline to see: it thins and fades as it travels and has gone before
 * it reaches the far side. Clipped to the element's own shape, or to its bounds
 * where it has none.
 */
private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawRing(
    origin: Offset,
    t: Float,
    color: Color,
    shape: Shape?,
) {
    val far = maxOf(
        hypot(origin.x, origin.y),
        hypot(size.width - origin.x, origin.y),
        hypot(origin.x, size.height - origin.y),
        hypot(size.width - origin.x, size.height - origin.y),
    )
    val radius = (far * 0.9f * t).coerceAtLeast(1f)
    val fade = (1f - t)
    val alpha = RING_ALPHA * fade * fade
    if (alpha <= 0.002f) return
    val brush = Brush.radialGradient(
        0f to Color.Transparent,
        0.55f to Color.Transparent,
        0.86f to color.copy(alpha = alpha),
        1f to Color.Transparent,
        center = origin,
        radius = radius,
    )
    if (shape == null) {
        clipRect { drawCircle(brush = brush, radius = radius, center = origin) }
    } else {
        val path = Path().apply { addOutline(shape.createOutline(size, layoutDirection, this@drawRing)) }
        clipPath(path) { drawCircle(brush = brush, radius = radius, center = origin) }
    }
}

/**
 * How long a tap waits before it is delivered, so the ring is seen to start.
 * Short: ninety milliseconds is about where a delay turns into lag.
 */
const val TAP_FEEDBACK_MS = 90L

/** How long the ring takes to cross an element and fade. */
private const val RING_MS = 420

/** The ring's strongest, as it leaves the finger. Light: it is over pictures. */
private const val RING_ALPHA = 0.30f
