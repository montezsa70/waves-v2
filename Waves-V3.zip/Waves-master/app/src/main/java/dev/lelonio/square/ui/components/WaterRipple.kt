package dev.lelonio.square.ui.components

import android.content.Context
import android.os.Build
import android.provider.Settings
import androidx.annotation.RequiresApi
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.Stable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

/**
 * The signature of the player: a still body of water, disturbed once.
 *
 * Every [RIPPLE_INTERVAL_MS] while a song is playing, a gentle train of rings leaves the
 * middle of the artwork and travels out across the whole screen, bending the
 * picture it passes over — the actual blurred artwork and its gradient, not a
 * circle drawn on top of them. It is meant to be almost missed: a few pixels of
 * refraction, no outline, no glow, no tint. The colours are the record's own
 * because nothing is added; the pixels are only *moved*.
 *
 * ## How it is made
 *
 * One AGSL `RuntimeShader` applied as the `renderEffect` of the background's own
 * graphics layer. The GPU re-samples the layer the app already rendered, so
 * nothing is captured to a bitmap and nothing is drawn twice. Only the uniforms
 * change per frame, and those are written inside the `graphicsLayer` block, which
 * Compose defers to the draw phase: the ripple never recomposes anything.
 *
 * ## What it costs when it is not running
 *
 * Nothing. The render effect is only attached while a wave is in flight (about
 * 10 s in every 30), so for the other two thirds of the time the background is the
 * plain layer it always was, with no offscreen pass.
 *
 * ## When it does not run
 *
 *  - below Android 13 (AGSL does not exist; the screen is simply still);
 *  - while nothing is playing, and while the app is not on screen — the wait is
 *    inside `repeatOnLifecycle(STARTED)`, so it is cancelled with the activity;
 *  - when the person has asked the system to remove animations
 *    (`ANIMATOR_DURATION_SCALE == 0`, which is what the accessibility switch
 *    sets).
 */
/**
 * One wave clock, shared by every layer that is to ripple together.
 *
 * The artwork on the player is two layers — the sharp picture and the blurred
 * field it dissolves into — and a wave that crossed only one of them would
 * look like a glitch. Both read the same [wave] and [gain], so they bend as one.
 */
@Stable
class WaterRippleState internal constructor() {
    /** 0 → 1 across one wave. Read only inside graphicsLayer blocks. */
    internal val wave = Animatable(0f)

    /** Brought to 0 briefly when a wave is cut short, so it dissolves. */
    internal val gain = Animatable(1f)
}

/** The state the player's artwork layers share; null where there is no ripple. */
val LocalWaterRipple = staticCompositionLocalOf<WaterRippleState?> { null }

/**
 * Runs the schedule: one wave every [RIPPLE_INTERVAL_MS] while [active].
 *
 * Suspends whenever the app leaves the screen (`repeatOnLifecycle`) and starts
 * with a fresh interval when it comes back. Does nothing below Android 13.
 */
@Composable
fun rememberWaterRipple(active: Boolean): WaterRippleState {
    val context = LocalContext.current
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    val state = remember { WaterRippleState() }

    LaunchedEffect(active, lifecycle) {
        if (!active || Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return@LaunchedEffect
        try {
            lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
                // The first wave comes one interval after the player is
                // opened; after that, one starts every interval, counted from
                // the start of the last, so the quiet between them is the
                // interval less the wave's own length.
                var first = true
                while (true) {
                    delay(if (first) RIPPLE_INTERVAL_MS else RIPPLE_INTERVAL_MS - RIPPLE_DURATION_MS)
                    first = false
                    // Asked again on every pass: the setting can change while
                    // the player is open, and a check made once would not see it.
                    if (!rippleAllowed(context)) continue
                    state.wave.snapTo(0f)
                    // Linear in time; the easing is in the shader's inputs,
                    // where the front and the dissipation get their own curves.
                    state.wave.animateTo(1f, tween(RIPPLE_DURATION_MS, easing = LinearEasing))
                    state.wave.snapTo(0f)
                }
            }
        } finally {
            // Cut short — paused, backgrounded, or the player closed. If a wave
            // was in the air, let it die away rather than blink out.
            withContext(NonCancellable) {
                if (state.wave.value in 0.001f..0.999f) {
                    withTimeoutOrNull(FADE_OUT_MS + 200L) {
                        state.gain.animateTo(0f, tween(FADE_OUT_MS.toInt()))
                    }
                }
                state.wave.snapTo(0f)
                state.gain.snapTo(1f)
            }
        }
    }
    return state
}

/**
 * Bends this layer with the wave in [state].
 *
 * [origin] is where the wave starts, in this layer's own pixels; the player
 * passes the middle of the artwork. With a null [state], or below Android 13
 * (no AGSL), the modifier does nothing.
 */
@Composable
fun Modifier.waterRipple(
    state: WaterRippleState?,
    origin: (Size) -> Offset = { Offset(it.width / 2f, it.height / 2f) },
): Modifier {
    if (state == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return this
    return waterRippleApi33(state, origin)
}

@RequiresApi(Build.VERSION_CODES.TIRAMISU)
@Composable
private fun Modifier.waterRippleApi33(
    state: WaterRippleState,
    origin: (Size) -> Offset,
): Modifier {
    val density = LocalDensity.current
    // One program per layer: uniforms are set per draw, and two layers sharing
    // one instance would overwrite each other's values.
    val shader = remember { android.graphics.RuntimeShader(RIPPLE_AGSL) }
    val currentOrigin by rememberUpdatedState(origin)

    // A few dp of travel at the strongest point. Density-scaled so it looks the
    // same on every screen, and kept small: noticed on the second or third
    // time, not the first.
    val maxShiftPx = with(density) { MAX_SHIFT_DP.dp.toPx() }
    val waveLengthPx = with(density) { WAVELENGTH_DP.dp.toPx() }
    val speedPx = with(density) { SPEED_DP_PER_S.dp.toPx() }
    val decayPx = with(density) { DECAY_DP.dp.toPx() }

    return this.graphicsLayer {
        val t = state.wave.value
        // At rest there is no effect at all — not a zero-strength one.
        if (t <= 0f || t >= 1f) {
            renderEffect = null
            return@graphicsLayer
        }
        val w = size.width
        val h = size.height
        val o = currentOrigin(size)
        val ox = o.x
        val oy = o.y
        // The leading ring travels at a steady, unhurried pace — water, not a
        // shockwave. The rings behind it keep coming for as long as the wave
        // lasts, so what is on screen is a train of them, not one.
        val seconds = t * RIPPLE_DURATION_MS / 1000f

        shader.setFloatUniform("resolution", w, h)
        shader.setFloatUniform("origin", ox, oy)
        shader.setFloatUniform("front", speedPx * seconds + waveLengthPx)
        shader.setFloatUniform("waveLength", waveLengthPx)
        shader.setFloatUniform("decayLength", decayPx)
        shader.setFloatUniform("amplitude", maxShiftPx * amplitude(t) * state.gain.value)

        renderEffect = android.graphics.RenderEffect
            .createRuntimeShaderEffect(shader, "content")
            .asComposeRenderEffect()
    }
}

/** True when a wave may run right now. */
private fun rippleAllowed(context: Context): Boolean {
    // "Remove animations" in the accessibility settings sets the animator scale
    // to zero. The ripple is decoration; with that on there is none.
    val scale = Settings.Global.getFloat(
        context.contentResolver,
        Settings.Global.ANIMATOR_DURATION_SCALE,
        1f,
    )
    if (scale == 0f) return false
    return true
}

/**
 * How strong the wave is at time [t], 0 to 1 across its whole length.
 *
 * It rises slowly over the first tenth so there is no edge at the start, holds
 * while the rings travel, then lets go over the last third. It has gone to
 * exactly zero at the end, which is what lets the picture return without a
 * jump.
 */
private fun amplitude(t: Float): Float {
    val rise = smooth((t / 0.10f).coerceIn(0f, 1f))
    val fall = 1f - smooth(((t - 0.62f) / 0.38f).coerceIn(0f, 1f))
    return rise * fall
}

private fun smooth(x: Float): Float = x * x * (3f - 2f * x)

/** Time from the start of one wave to the start of the next. */
const val RIPPLE_INTERVAL_MS = 30_000L

/** One wave, from the first ring to the last trace: slow, and long enough to watch. */
const val RIPPLE_DURATION_MS = 10_000

private const val FADE_OUT_MS = 600L
private const val MAX_SHIFT_DP = 6f
private const val WAVELENGTH_DP = 110f

/** How fast each ring travels outward. Slow: about one ring a second. */
private const val SPEED_DP_PER_S = 85f

/** Distance over which the rings lose half their strength: they thin as they go. */
private const val DECAY_DP = 420f

/**
 * The displacement program.
 *
 * `content` is the layer's own rendering. For every pixel this asks "which pixel
 * of the original should I be showing here?" and answers with one a few pixels
 * towards or away from the centre of the wave. A pixel is never darkened,
 * brightened or recoloured; the picture is only re-sampled, so the record's
 * colours are exactly what they were.
 *
 * The disturbance is a short train of crests that trails behind a moving front.
 * Its envelope is a wide Gaussian and the crests inside it are a sine, so there
 * is no ring edge anywhere: the displacement is smooth in space, and the
 * outward push and the inward pull alternate, which is what reads as water
 * rather than as a shockwave.
 */
private const val RIPPLE_AGSL = """
uniform shader content;
uniform float2 resolution;
uniform float2 origin;
uniform float front;       // distance the leading ring has reached, px
uniform float waveLength;  // px, crest to crest
uniform float decayLength; // px, over which the rings fade as they travel
uniform float amplitude;   // px, at the strongest point

half4 main(float2 p) {
    float2 d = p - origin;
    float r = length(d);

    // Behind the leading ring is positive. Nothing ahead of it is touched yet.
    float behind = front - r;

    // A soft start at the leading edge, so there is no visible rim.
    float lead = smoothstep(0.0, waveLength * 1.2, behind);

    // The rings thin out with distance instead of ending abruptly, and are
    // calmed at the very middle, where the direction of a push has no meaning.
    float spatial = 1.0 / (1.0 + r / decayLength);
    float centre = smoothstep(0.0, waveLength * 0.6, r);

    // One ring after another, all the way back to where they start. The phase
    // advances with the front, so the crests travel outward.
    float crest = sin(behind / waveLength * 6.2831853);

    // Push along the line from the centre. Guarded at r = 0.
    float2 dir = d / max(r, 0.0001);
    float2 shift = dir * crest * lead * spatial * centre * amplitude;

    // Stay inside the layer: the edges carry on rather than turning
    // transparent.
    float2 q = clamp(p - shift, float2(0.5), resolution - float2(0.5));
    return content.eval(q);
}
"""
