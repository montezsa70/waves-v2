package dev.lelonio.square.ui.player

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalDensity
import com.adamglin.phosphoricons.regular.DotsThree
import dev.lelonio.square.ui.glass.LocalGlassEffectConfig
import dev.lelonio.square.ui.glass.liquidGlass
import dev.lelonio.square.ui.glass.shapes.ContinuousCapsule
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.sin
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.horizontalScroll
import dev.lelonio.square.ui.components.horizontalEdgeFade
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import dev.lelonio.square.R
import dev.lelonio.square.data.Lyrics
import dev.lelonio.square.playback.EffectPreset
import androidx.compose.foundation.layout.RowScope
import dev.lelonio.square.ui.glass.LiquidBottomTab
import dev.lelonio.square.ui.glass.LiquidBottomTabs
import dev.lelonio.square.ui.glass.LiquidSlider
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.roundToInt
import com.adamglin.PhosphorIcons
import com.adamglin.phosphoricons.Fill
import com.adamglin.phosphoricons.Regular
import com.adamglin.phosphoricons.regular.Plus
import com.adamglin.phosphoricons.regular.SlidersHorizontal
import com.adamglin.phosphoricons.regular.TextAa
import com.adamglin.phosphoricons.fill.SlidersHorizontal
import com.adamglin.phosphoricons.fill.TextAa
import com.adamglin.phosphoricons.fill.Queue
import com.adamglin.phosphoricons.fill.VinylRecord
import com.adamglin.phosphoricons.regular.Queue
import com.adamglin.phosphoricons.regular.VinylRecord
import com.adamglin.phosphoricons.fill.Info
import com.adamglin.phosphoricons.regular.Info
import com.adamglin.phosphoricons.regular.X
import com.adamglin.phosphoricons.regular.Sparkle
import dev.lelonio.square.ui.glass.pressable

/** Which panel is open below the transport controls. */
enum class PlayerPanel {
    NONE,
    QUEUE,
    LYRICS,
    EFFECTS,

    /** Who made the track: performers, writers, producers, and the label. */
    INFO,

    /**
     * The Connect device list and the playlist picker.
     *
     * Both used to open as modals over the transport. The player already has one
     * place where a second thing is shown — the slot the cover lives in — and
     * two mechanisms for the same job meant the screen sometimes dimmed itself
     * and sometimes did not, depending on which button had been pressed.
     */
    DEVICES,
    ADD_TO_PLAYLIST,
}

@Composable
fun PlayerPanelSection(
    panel: PlayerPanel,
    onSelect: (PlayerPanel) -> Unit,
    queue: List<QueueEntry>,
    lyrics: Lyrics?,
    lyricsLoading: Boolean,
    positionMs: androidx.compose.runtime.State<Long>,
    onPlayQueueItem: (Int) -> Unit,
    onSeek: (Long) -> Unit,
    speed: Float,
    pitch: Float,
    reverb: Float,
    onSpeed: (Float) -> Unit,
    onPitch: (Float) -> Unit,
    onReverb: (Float) -> Unit,
    presets: List<EffectPreset>,
    onApplyPreset: (EffectPreset) -> Unit,
    onSavePreset: (String) -> Unit,
    onDeletePreset: (String) -> Unit,
    /** The layer the panel refracts; see the liquid-glass note in PlayerScreen. */
    backdrop: dev.lelonio.square.ui.glass.backdrop.Backdrop,
    modifier: Modifier = Modifier,
    /** False on a phone held sideways, where the cover is beside the views already. */
    showCover: Boolean = true,
) {
    Column(
        modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        // The same segmented control the tab bar uses, because this is the same
        // kind of choice: three views of one screen, exactly one of them
        // showing. Three separate toggles said "three independent switches",
        // which is not what cover, lyrics and effects are.
        //
        // The queue in here too: it opens in the same middle of the screen as
        // the others, and a button for it beside the title was one more
        // control in a row that already had the radio and the heart.
        // Whether anything is being done to the sound right now.
        val speed by dev.lelonio.square.playback.AudioEffects.speed
            .collectAsStateWithLifecycle()
        val pitch by dev.lelonio.square.playback.AudioEffects.pitch
            .collectAsStateWithLifecycle()
        val reverb by dev.lelonio.square.playback.AudioEffects.reverb
            .collectAsStateWithLifecycle()
        val effectsOn = speed != 1f || pitch != 1f || reverb > 0f
        val karaoke by dev.lelonio.square.playback.AudioEffects.karaoke
            .collectAsStateWithLifecycle()
        // The official SDK mixes its own audio, so it has no effects to offer.
        val sdkPlayback by dev.lelonio.square.playback.websdk.WebSdkRecovery.inUse
            .collectAsStateWithLifecycle()
        val karaokeOn = karaoke > 0f && !sdkPlayback

        // Four icons: lyrics, credits, effects and the queue. The cover is not
        // one of them; it is where the player rests, and tapping the lit icon
        // again (or swiping the panel away) comes back to it.
        //
        // On a phone held sideways the cover is already beside the views, so
        // there is nothing to go back to and the lit icon stays lit.
        fun toggle(target: PlayerPanel) {
            onSelect(if (panel == target && showCover) PlayerPanel.NONE else target)
        }

        // The four icons live in one pane of liquid glass, like the plus beside
        // the title. A few seconds after the player opens the pane squeezes in
        // from both ends and the icons gather, thinning as they go, into a
        // single "more"; a tap on it lets them back out. Both directions are on
        // an under-damped spring, so the pane overshoots and settles like a drop
        // of water finding its shape.
        var expanded by remember { mutableStateOf(true) }
        LaunchedEffect(Unit) {
            delay(COLLAPSE_AFTER_MS)
            expanded = false
        }
        val open = remember { Animatable(1f) }
        LaunchedEffect(expanded) {
            open.animateTo(
                targetValue = if (expanded) 1f else 0f,
                animationSpec = spring(
                    dampingRatio = 0.6f,
                    stiffness = Spring.StiffnessLow,
                ),
            )
        }

        val items = buildList {
            add(
                PanelItem(
                    PhosphorIcons.Regular.TextAa, PhosphorIcons.Fill.TextAa,
                    stringResource(R.string.lyrics), panel == PlayerPanel.LYRICS,
                    // The karaoke lives in this view and keeps working with the
                    // panel shut; see the same halo on the effects icon.
                    karaokeOn,
                ) { toggle(PlayerPanel.LYRICS) },
            )
            add(
                PanelItem(
                    PhosphorIcons.Regular.Info, PhosphorIcons.Fill.Info,
                    stringResource(R.string.credits), panel == PlayerPanel.INFO, false,
                ) { toggle(PlayerPanel.INFO) },
            )
            if (!sdkPlayback) add(
                PanelItem(
                    PhosphorIcons.Regular.SlidersHorizontal, PhosphorIcons.Fill.SlidersHorizontal,
                    stringResource(R.string.effects), panel == PlayerPanel.EFFECTS, effectsOn,
                ) { toggle(PlayerPanel.EFFECTS) },
            )
            add(
                PanelItem(
                    PhosphorIcons.Regular.Queue, PhosphorIcons.Fill.Queue,
                    stringResource(R.string.queue), panel == PlayerPanel.QUEUE, false,
                ) { toggle(PlayerPanel.QUEUE) },
            )
        }
        val anyLit = items.any { it.selected }
        val anyMarked = items.any { it.marked }

        val density = LocalDensity.current
        BoxWithConstraints(
            Modifier
                .fillMaxWidth(0.9f)
                .padding(top = 14.dp),
            contentAlignment = Alignment.Center,
        ) {
            val fullPx = with(density) { maxWidth.toPx() }
            val heightPx = with(density) { PILL_HEIGHT.roundToPx() }
            val restPx = with(density) { PILL_HEIGHT.toPx() }
            val step = fullPx / items.size

            Box(
                Modifier
                    // Pressed as a whole while it is the one round button;
                    // while open the icons answer for themselves.
                    .pressable(onClick = { expanded = true }, pressedScale = 0.9f, enabled = !expanded)
                    // The width is read in the layout phase, so the spring
                    // re-measures this pane and nothing above it.
                    .layout { measurable, _ ->
                        val p = open.value.coerceIn(-0.12f, 1.04f)
                        val w = (restPx + (fullPx - restPx) * p)
                            .coerceAtLeast(restPx * 0.85f)
                            .roundToInt()
                        val placeable = measurable.measure(
                            androidx.compose.ui.unit.Constraints.fixed(w, heightPx),
                        )
                        layout(w, heightPx) { placeable.place(0, 0) }
                    }
                    // A little taller through the middle of the squeeze: the
                    // glass bulges as it is pushed in from the sides.
                    .graphicsLayer {
                        val bulge = 1f + 0.07f * sin(PI.toFloat() * open.value.coerceIn(0f, 1f))
                        scaleY = bulge
                    }
                    .clip(ContinuousCapsule())
                    .liquidGlass(
                        config = LocalGlassEffectConfig.current,
                        shape = ContinuousCapsule(),
                        ownBackdrop = backdrop,
                        highlightAlpha = BarHighlightAlpha,
                    ),
                contentAlignment = Alignment.Center,
            ) {
                items.forEachIndexed { index, item ->
                    PanelIcon(
                        icon = item.icon,
                        activeIcon = item.activeIcon,
                        label = item.label,
                        selected = item.selected,
                        marked = item.marked,
                        enabled = expanded,
                        modifier = Modifier.graphicsLayer {
                            val p = open.value
                            // Each icon is walked in towards the middle of the
                            // pane as it closes, and out again as it opens.
                            translationX = (index - (items.size - 1) / 2f) * step * p
                            val shown = smoothStep(((p - 0.15f) / 0.6f).coerceIn(0f, 1f))
                            alpha = shown
                            val scale = 0.4f + 0.6f * p.coerceIn(0f, 1f)
                            scaleX = scale
                            scaleY = scale
                        },
                    ) { item.onClick() }
                }

                // What the icons become: one glyph, arriving as they leave.
                Icon(
                    imageVector = PhosphorIcons.Regular.DotsThree,
                    contentDescription = stringResource(R.string.more),
                    tint = if (anyLit || anyMarked) GlassInk else GlassInkDim,
                    modifier = Modifier
                        .size(28.dp)
                        .graphicsLayer {
                            val p = open.value
                            // Not clamped: the overshoot of the spring lets it
                            // pop slightly past its size as it lands.
                            val arrive = 1f - p
                            alpha = smoothStep(((arrive - 0.3f) / 0.6f).coerceIn(0f, 1f))
                            val scale = 0.5f + 0.5f * arrive.coerceIn(0f, 1.15f)
                            scaleX = scale
                            scaleY = scale
                            rotationZ = 90f * p.coerceIn(0f, 1f)
                        },
                )
            }
        }
    }
}

/** How long after the player opens before the icons gather into "more". */
private const val COLLAPSE_AFTER_MS = 3_000L

/** The same height the bare row of icons had, so nothing below moves. */
private val PILL_HEIGHT = 48.dp

private fun smoothStep(x: Float): Float = x * x * (3f - 2f * x)

private class PanelItem(
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val activeIcon: androidx.compose.ui.graphics.vector.ImageVector,
    val label: String,
    val selected: Boolean,
    val marked: Boolean,
    val onClick: () -> Unit,
)

/**
 * One of the four icons under the transport.
 *
 * Bare: a glyph, filled while its view is the one showing, and a press that
 * shrinks it under the finger. The touch target is a full 56 by 48 so four
 * icons spread over a phone's width are easy to hit with a thumb.
 */
@Composable
private fun PanelIcon(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    /** The filled cut of the same glyph, for the view being shown. */
    activeIcon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    selected: Boolean,
    /**
     * A light on the icon: what is behind it is doing something right now.
     *
     * Used by the effects, which are the one view whose settings go on working
     * after it is closed — a song playing a third slower with the panel shut
     * looks, from this row, exactly like a song playing normally.
     */
    marked: Boolean = false,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    onClick: () -> Unit,
) {
    androidx.compose.foundation.layout.Box(
        modifier
            .size(width = 56.dp, height = 48.dp)
            .pressable(onClick = onClick, pressedScale = 0.86f, enabled = enabled),
        contentAlignment = Alignment.Center,
    ) {
        if (marked) {
            androidx.compose.foundation.layout.Box(
                Modifier
                    .size(34.dp)
                    .background(
                        androidx.compose.ui.graphics.Brush.radialGradient(
                            listOf(GlassInk.copy(alpha = 0.28f), androidx.compose.ui.graphics.Color.Transparent),
                        ),
                        androidx.compose.foundation.shape.CircleShape,
                    ),
            )
        }
        Icon(
            imageVector = if (selected) activeIcon else icon,
            contentDescription = label,
            tint = when {
                selected -> GlassInk
                marked -> GlassInk.copy(alpha = 0.85f)
                else -> GlassInkDim
            },
            modifier = Modifier.size(26.dp),
        )
    }
}

/** One row of the upcoming-tracks list. */
data class QueueEntry(
    val index: Int,
    /** What the row is, so a list that loses one can animate the rest. */
    val uri: String,
    val title: String,
    val artist: String,
    val isCurrent: Boolean,
    /** Already heard: shown above the playing track, dimmed. */
    val played: Boolean = false,
    val recommended: Boolean = false,
    /** Put in the queue by hand, as "play next": the "Next in queue" section. */
    val queued: Boolean = false,
    /** The playlist or album it came from, for the "Next from" heading. */
    val contextLabel: String = "",
)

/**
 * Tempo, pitch and reverb.
 *
 * Speed and pitch are separate controls on purpose: resampling would move both
 * at once, and the whole point of asking for them separately is being able to
 * slow a track down without dropping it an octave. The platform's time
 * stretcher does the work — see [dev.lelonio.square.playback.AudioOutput].
 */
@Composable
internal fun EffectsPanel(
    speed: Float,
    pitch: Float,
    reverb: Float,
    onSpeed: (Float) -> Unit,
    onPitch: (Float) -> Unit,
    onReverb: (Float) -> Unit,
    presets: List<EffectPreset>,
    onApplyPreset: (EffectPreset) -> Unit,
    onSavePreset: (String) -> Unit,
    onDeletePreset: (String) -> Unit,
    backdrop: dev.lelonio.square.ui.glass.backdrop.Backdrop,
) {
    var naming by remember { mutableStateOf(false) }

    Column(
        Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
    ) {
        PresetRow(
            presets = presets,
            speed = speed,
            pitch = pitch,
            reverb = reverb,
            onApply = onApplyPreset,
            onDelete = onDeletePreset,
            onSaveCurrent = { naming = true },
        )

        if (naming) {
            SavePresetDialog(
                onDismiss = { naming = false },
                onConfirm = {
                    onSavePreset(it)
                    naming = false
                },
            )
        }

        EffectSlider(
            label = stringResource(R.string.speed),
            value = speed,
            // Below half speed the stretcher smears badly and above double the
            // track stops being recognisable; both ends are past the useful part.
            scale = RatioScale,
            reading = { "%.2f×".format(it) },
            backdrop = backdrop,
            onChange = onSpeed,
            onReset = { onSpeed(1f) },
        )

        EffectSlider(
            label = stringResource(R.string.pitch),
            value = pitch,
            scale = RatioScale,
            // Semitones read better than a ratio for pitch: "+3" is a musical
            // amount, "1.19×" is not.
            reading = ::formatSemitones,
            backdrop = backdrop,
            onChange = onPitch,
            onReset = { onPitch(1f) },
        )

        val off = stringResource(R.string.off)
        EffectSlider(
            label = stringResource(R.string.reverb),
            value = reverb,
            scale = LinearScale,
            reading = { if (it <= 0f) off else "${(it * 100).roundToInt()}%" },
            backdrop = backdrop,
            onChange = onReverb,
            onReset = { onReverb(0f) },
        )

        // How late the words come, for the headphones in use (#143): the
        // sound reaches Bluetooth headphones a moment after the player has
        // it, and the words are timed to the player. Kept per output, so the
        // phone's speaker stays as it was.
        val context = androidx.compose.ui.platform.LocalContext.current
        val store = remember(context) {
            (context.applicationContext as dev.lelonio.square.SquareApplication).preferences
        }
        val output = rememberAudioOutput()
        val offsets by store.lyricsOffsets.collectAsStateWithLifecycle()
        EffectSlider(
            label = stringResource(R.string.lyrics_delay) + (output.name?.let { " · $it" } ?: ""),
            value = (offsets[output.key] ?: 0) / 1000f,
            scale = DelayScale,
            reading = { "%+.2f s".format(it) },
            backdrop = backdrop,
            onChange = { store.setLyricsOffset(output.key, (it * 1000).roundToInt()) },
            onReset = { store.setLyricsOffset(output.key, 0) },
        )

        SleepTimerRow()
    }
}

/**
 * When to stop, under the things that change how it sounds.
 *
 * Here rather than in the settings because it is about the song playing now,
 * like everything else in this panel, and because it is set from bed. What it
 * sets lives in the service; see SleepTimer.
 */
@Composable
private fun SleepTimerRow() {
    val endsAt by dev.lelonio.square.playback.SleepTimer.endsAt.collectAsStateWithLifecycle()
    val chosen by dev.lelonio.square.playback.SleepTimer.minutes.collectAsStateWithLifecycle()
    val atTrackEnd by dev.lelonio.square.playback.SleepTimer.atTrackEnd.collectAsStateWithLifecycle()

    // Read once a second while something is running, and not at all otherwise:
    // a clock nobody set should cost nothing.
    var left by remember { mutableStateOf(dev.lelonio.square.playback.SleepTimer.remaining()) }
    LaunchedEffect(endsAt) {
        while (endsAt != null) {
            left = dev.lelonio.square.playback.SleepTimer.remaining()
            kotlinx.coroutines.delay(1_000)
        }
        left = null
    }

    Text(
        stringResource(R.string.sleep_timer),
        style = MaterialTheme.typography.labelLarge,
        color = GlassInkDim,
        modifier = Modifier.padding(top = 24.dp, bottom = 8.dp),
    )

    val rowScroll = rememberScrollState()
    Row(
        Modifier
            .fillMaxWidth()
            .then(dev.lelonio.square.ui.components.SideScrollNoBack)
            .horizontalEdgeFade(rowScroll)
            .horizontalScroll(rowScroll),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        SleepChip(
            label = stringResource(R.string.off),
            selected = endsAt == null && !atTrackEnd,
            onClick = { dev.lelonio.square.playback.SleepTimer.cancel() },
        )
        SleepLengths.forEach { minutes ->
            SleepChip(
                label = stringResource(R.string.sleep_timer_minutes, minutes),
                selected = chosen == minutes,
                onClick = { dev.lelonio.square.playback.SleepTimer.inMinutes(minutes) },
            )
        }
        SleepChip(
            label = stringResource(R.string.sleep_timer_track_end),
            selected = atTrackEnd,
            onClick = { dev.lelonio.square.playback.SleepTimer.atEndOfTrack() },
        )
    }

    // What the chosen chip means, in words and counting down: a lit chip says
    // which length was asked for, not how much of it is left.
    val running = left
    if (atTrackEnd || running != null) {
        Text(
            if (atTrackEnd) {
                stringResource(R.string.sleep_timer_track_end_active)
            } else {
                stringResource(
                    R.string.sleep_timer_left,
                    dev.lelonio.square.ui.library.formatDuration(running ?: 0L),
                )
            },
            style = MaterialTheme.typography.bodySmall,
            color = GlassInkDim,
            modifier = Modifier.padding(top = 10.dp),
        )
    }
}

/** A chip of the timer row, drawn like the preset chips above it. */
@Composable
private fun SleepChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Text(
        label,
        style = MaterialTheme.typography.bodySmall,
        maxLines = 1,
        color = if (selected) GlassInk else GlassInkDim,
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(
                if (selected) {
                    MaterialTheme.colorScheme.primary
                } else {
                    MaterialTheme.colorScheme.background
                },
            )
            .pressable(onClick, pressedScale = 0.94f)
            .padding(horizontal = 14.dp, vertical = 8.dp),
    )
}

/** The lengths offered, which are the ones every player offers. */
private val SleepLengths = listOf(5, 15, 30, 45, 60)

/**
 * The preset chips.
 *
 * A custom preset can be deleted from its own chip once it is the selected one,
 * rather than through a separate edit mode: there are only ever a handful of
 * these, and a mode to manage four chips is more interface than the job needs.
 */
@Composable
private fun PresetRow(
    presets: List<EffectPreset>,
    speed: Float,
    pitch: Float,
    reverb: Float,
    onApply: (EffectPreset) -> Unit,
    onDelete: (String) -> Unit,
    onSaveCurrent: () -> Unit,
) {
    Text(
        stringResource(R.string.presets),
        style = MaterialTheme.typography.labelLarge,
        color = GlassInkDim,
        modifier = Modifier.padding(bottom = 8.dp),
    )

    val rowScroll = rememberScrollState()
    Row(
        Modifier
            .fillMaxWidth()
            .then(dev.lelonio.square.ui.components.SideScrollNoBack)
            .horizontalEdgeFade(rowScroll)
            .horizontalScroll(rowScroll),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        presets.forEach { preset ->
            val selected = preset.matches(speed, pitch, reverb)
            Row(
                Modifier
                    .clip(RoundedCornerShape(50))
                    .background(
                        if (selected) {
                            MaterialTheme.colorScheme.primary
                        } else {
                            MaterialTheme.colorScheme.background
                        },
                    )
                    .clickable { onApply(preset) }
                    .padding(start = 14.dp, end = if (selected && !preset.builtIn) 6.dp else 14.dp)
                    .padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    // "Slowed + Reverb" and "Sped Up" are the names these edits
                    // go by everywhere and are left alone; "Original" is a plain
                    // word and is read from resources.
                    if (preset.id == "original") stringResource(R.string.preset_original)
                    else preset.name,
                    style = MaterialTheme.typography.bodySmall,
                    maxLines = 1,
                    color = if (selected) GlassInk else GlassInkDim,
                )
                if (selected && !preset.builtIn) {
                    Icon(
                        PhosphorIcons.Regular.X,
                        contentDescription = stringResource(R.string.delete_preset, preset.name),
                        tint = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier
                            .padding(start = 4.dp)
                            .size(16.dp)
                            .clip(RoundedCornerShape(50))
                            .clickable { onDelete(preset.id) },
                    )
                }
            }
        }

        Row(
            Modifier
                .clip(RoundedCornerShape(50))
                .clickable(onClick = onSaveCurrent)
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                PhosphorIcons.Regular.Plus,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(16.dp),
            )
            Text(
                stringResource(R.string.save),
                style = MaterialTheme.typography.bodySmall,
                color = GlassInk,
                modifier = Modifier.padding(start = 4.dp),
            )
        }
    }
}

@Composable
private fun SavePresetDialog(onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    // Upstream's GlassSheet with a field, as every question for a name is.
    dev.lelonio.square.ui.components.NameDialog(
        title = stringResource(R.string.save_preset),
        initial = "",
        confirmLabel = stringResource(R.string.save),
        placeholder = stringResource(R.string.name),
        onConfirm = onConfirm,
        onDismiss = onDismiss,
    )
}

/**
 * How a value is laid out along the track.
 *
 * Speed and pitch are ratios, and distance between ratios is multiplicative:
 * half speed and double speed are the same amount of change, one octave either
 * way. Placed linearly, 1.0 lands a third of the way along a 0.5 to 2 track,
 * so normal sits off centre and the two halves of the control mean different
 * amounts. Placing by log2 fixes both at once, and it is also how the ear
 * hears the difference.
 */
private interface SliderScale {
    val positions: ClosedFloatingPointRange<Float>
    fun position(value: Float): Float
    fun value(position: Float): Float
}

/** Symmetric around 1.0: half at one end, double at the other, normal in the middle. */
private object RatioScale : SliderScale {
    override val positions = -1f..1f
    override fun position(value: Float) = (ln(value.toDouble()) / ln(2.0)).toFloat()
    override fun value(position: Float) = 2f.pow(position)
}

/** Seconds either way, the words later to the right. */
private object DelayScale : SliderScale {
    override val positions = -1f..1f
    override fun position(value: Float) = value
    override fun value(position: Float) = position
}

/** For a plain amount, where the number already means what it says. */
private object LinearScale : SliderScale {
    override val positions = 0f..1f
    override fun position(value: Float) = value
    override fun value(position: Float) = position
}

@Composable
private fun EffectSlider(
    label: String,
    value: Float,
    scale: SliderScale,
    /**
     * Given the value under the finger, not the one the player has.
     *
     * The two differ for the length of a drag, and reading the settled value
     * meant the number stood still while the thumb moved: the control gave no
     * answer to "what am I choosing?" until it had already been chosen.
     */
    reading: (Float) -> String,
    backdrop: dev.lelonio.square.ui.glass.backdrop.Backdrop,
    onChange: (Float) -> Unit,
    onReset: () -> Unit,
) {
    // What the thumb shows while the player has not caught up yet.
    //
    // The player is told the new value only once the drag settles — writing it
    // every frame starves the audio output — so between the two the slider has
    // to speak for itself, or it springs back under the finger.
    var dragged by remember { mutableStateOf<Float?>(null) }
    val shown = dragged ?: value
    LaunchedEffect(value) {
        if (dragged != null && kotlin.math.abs(value - dragged!!) < 0.0005f) dragged = null
    }

    Column(Modifier.padding(top = 6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                label.uppercase(),
                style = MaterialTheme.typography.labelLarge,
                color = GlassInkDim,
                modifier = Modifier.weight(1f),
            )
            Text(reading(shown), style = MaterialTheme.typography.titleMedium)
            // A one-tap way back to unmodified. Dragging a slider to exactly 1.0
            // is fiddly, and a stuck-off-centre value is the kind of thing that
            // gets mistaken for broken playback.
            Text(
                stringResource(R.string.reset),
                style = MaterialTheme.typography.bodySmall,
                color = GlassInk,
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .clickable {
                        // Or the thumb stays on the dragged value while the
                        // player goes back to normal under it.
                        dragged = null
                        onReset()
                    }
                    .padding(horizontal = 10.dp, vertical = 4.dp),
            )
        }
        LiquidSlider(
            // The track is in position space, not value space: everything the
            // slider itself does, the thumb, the fill, the animation, is even
            // along it, and the curve lives only in these two conversions.
            value = { scale.position(shown) },
            onValueChange = { position ->
                val v = scale.value(position)
                dragged = v
                onChange(v)
            },
            valueRange = scale.positions,
            // The smallest step worth animating to. Below this the thumb chases
            // values the ear cannot tell apart.
            visibilityThreshold = 0.001f,
            backdrop = backdrop,
            accentColor = MaterialTheme.colorScheme.primary,
            trackColor = GlassInk.copy(alpha = 0.22f),
            modifier = Modifier.padding(top = 4.dp),
        )
    }
}

/** Pitch ratio as semitones, the unit the control is actually thought in. */
private fun formatSemitones(pitch: Float): String {
    val semitones = 12.0 * (ln(pitch.toDouble()) / ln(2.0))
    return "%+.1f st".format(semitones)
}

@Composable
internal fun EmptyPanel(message: String) {
    Box(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 40.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            message,
            style = MaterialTheme.typography.bodyMedium,
            color = GlassInkDim,
        )
    }
}
