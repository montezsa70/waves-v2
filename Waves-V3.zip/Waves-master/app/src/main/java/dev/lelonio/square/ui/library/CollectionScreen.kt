package dev.lelonio.square.ui.library

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.layout
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.adamglin.PhosphorIcons
import com.adamglin.phosphoricons.Fill
import com.adamglin.phosphoricons.fill.ArrowCircleDown
import com.adamglin.phosphoricons.fill.Heart
import dev.lelonio.square.R
import dev.lelonio.square.data.CatalogPlaylist
import dev.lelonio.square.ui.components.Artwork
import dev.lelonio.square.ui.components.LocalCoverPalette
import dev.lelonio.square.ui.components.TabHeader
import dev.lelonio.square.ui.glass.pressable
import dev.lelonio.square.ui.theme.Ink
import dev.lelonio.square.ui.theme.InkDim
import kotlinx.coroutines.launch

/**
 * Collection: everything the listener has kept, in one place.
 *
 * Two cards at the top for the two things people keep songs in — the ones they
 * liked and the ones they downloaded — and under them the lists those songs
 * live in: downloaded lists, the account's playlists, saved albums. Each card
 * is a pane of frosted gradient in the colours of the cover that is playing,
 * so the page changes with the music like the rest of the app.
 */
@Composable
fun CollectionScreen(
    contentPadding: PaddingValues,
    /** The account's liked songs as a list to open; null when it has none yet. */
    liked: CatalogPlaylist?,
    likedCount: Int,
    /** The lists that have downloads behind them, as they can be drawn offline. */
    downloaded: List<CatalogPlaylist>,
    downloadedCount: Int,
    playlists: List<CatalogPlaylist>,
    albums: List<CatalogPlaylist>,
    onOpen: (CatalogPlaylist) -> Unit,
) {
    val cover = LocalCoverPalette.current
    val themeAccent = MaterialTheme.colorScheme.primary
    val first = cover.getOrNull(0) ?: themeAccent
    val second = cover.getOrNull(1) ?: first

    val gridState = rememberLazyGridState()
    val scope = rememberCoroutineScope()
    val nothing = liked == null && downloaded.isEmpty() && playlists.isEmpty() && albums.isEmpty()

    LazyVerticalGrid(
        state = gridState,
        columns = GridCells.Adaptive(minSize = 150.dp),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = 16.dp,
            end = 16.dp,
            top = contentPadding.calculateTopPadding(),
            bottom = contentPadding.calculateBottomPadding(),
        ),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp),
    ) {
        // Where every main tab's heading is, out of the grid's own 16 to the
        // page's edge; see TabHeader.
        item(key = "collection_title", span = { GridItemSpan(maxLineSpan) }) {
            TabHeader(
                title = stringResource(R.string.tab_collection),
                modifier = Modifier
                    .layout { measurable, constraints ->
                        val bleed = 16.dp.roundToPx()
                        val placeable = measurable.measure(
                            constraints.copy(
                                minWidth = constraints.maxWidth + 2 * bleed,
                                maxWidth = constraints.maxWidth + 2 * bleed,
                            ),
                        )
                        layout(constraints.maxWidth, placeable.height) { placeable.place(-bleed, 0) }
                    }
                    .padding(bottom = 6.dp),
            )
        }

        item(key = "liked_card") {
            KeptCard(
                title = stringResource(R.string.liked_songs),
                count = stringResource(R.string.collection_songs_count, likedCount),
                icon = PhosphorIcons.Fill.Heart,
                from = first,
                to = second,
            ) { liked?.let(onOpen) }
        }
        item(key = "downloaded_card") {
            KeptCard(
                title = stringResource(R.string.downloaded),
                count = stringResource(R.string.collection_songs_count, downloadedCount),
                icon = PhosphorIcons.Fill.ArrowCircleDown,
                from = second,
                to = first,
            ) {
                // The lists the downloads belong to are further down this page:
                // the card takes you to them.
                if (downloaded.isNotEmpty()) scope.launch { gridState.animateScrollToItem(DOWNLOADED_HEADING_INDEX) }
            }
        }

        if (nothing) {
            item(key = "collection_empty", span = { GridItemSpan(maxLineSpan) }) {
                Text(
                    stringResource(R.string.collection_empty),
                    style = MaterialTheme.typography.bodyMedium,
                    color = InkDim,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp, vertical = 32.dp),
                )
            }
        }

        section(
            key = "downloaded",
            title = R.string.downloaded,
            lists = downloaded,
            onOpen = onOpen,
        )
        section(
            key = "playlists",
            title = R.string.playlists,
            lists = playlists,
            onOpen = onOpen,
        )
        section(
            key = "albums",
            title = R.string.albums,
            lists = albums,
            onOpen = onOpen,
        )
    }
}

/**
 * Index of the "Downloaded" heading in the grid: the title and the two cards
 * come before it, and the empty message is only there when the heading is not.
 */
private const val DOWNLOADED_HEADING_INDEX = 3

private fun androidx.compose.foundation.lazy.grid.LazyGridScope.section(
    key: String,
    title: Int,
    lists: List<CatalogPlaylist>,
    onOpen: (CatalogPlaylist) -> Unit,
) {
    if (lists.isEmpty()) return
    item(key = "$key-heading", span = { GridItemSpan(maxLineSpan) }) {
        Text(
            stringResource(title),
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = Ink,
            modifier = Modifier.padding(top = 10.dp, bottom = 2.dp),
        )
    }
    items(lists, key = { "$key-${it.uri}" }) { list ->
        ListTile(list) { onOpen(list) }
    }
}

/**
 * One of the two big cards: a pane of frosted gradient with a rim of light.
 *
 * Flat rather than sampling what is behind it, like the mark on the home page:
 * the page scrolls, and a pane that photographs the screen on every frame of a
 * scroll costs far more than the effect is worth. The colours are the cover's,
 * the film on top is what makes it read as glass.
 */
@Composable
private fun KeptCard(
    title: String,
    count: String,
    icon: ImageVector,
    from: Color,
    to: Color,
    onClick: () -> Unit,
) {
    val shape = RoundedCornerShape(26.dp)
    Box(
        Modifier
            .fillMaxWidth()
            .height(132.dp)
            .clip(shape)
            .background(Brush.linearGradient(listOf(from.copy(alpha = 0.78f), to.copy(alpha = 0.34f))))
            // The frost: light from above, gone by the middle.
            .background(
                Brush.verticalGradient(
                    0f to Color.White.copy(alpha = 0.16f),
                    0.55f to Color.Transparent,
                ),
            )
            .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.18f)), shape)
            .pressable(onClick, pressedScale = 0.97f)
            .padding(16.dp),
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier
                .size(28.dp)
                .align(Alignment.TopStart),
        )
        Column(Modifier.align(Alignment.BottomStart)) {
            Text(
                title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                count,
                style = MaterialTheme.typography.bodySmall,
                color = Color.White.copy(alpha = 0.78f),
                maxLines = 1,
            )
        }
    }
}

/** A list in the grid: its cover with a thin rim, and its name under it. */
@Composable
private fun ListTile(list: CatalogPlaylist, onClick: () -> Unit) {
    Column(Modifier.pressable(onClick, pressedScale = 0.97f)) {
        Artwork(
            url = list.artworkUrl,
            title = list.name,
            corner = 20.dp,
            decodeSize = 180.dp,
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .border(
                    BorderStroke(1.dp, Color.White.copy(alpha = 0.10f)),
                    RoundedCornerShape(20.dp),
                ),
        )
        Text(
            list.name,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = Ink,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 8.dp),
        )
        Text(
            list.subtitle ?: stringResource(R.string.playlist),
            style = MaterialTheme.typography.bodySmall,
            color = InkDim,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}
