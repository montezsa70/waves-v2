package dev.lelonio.square.ui.components

import android.content.Context
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.annotation.RequiresApi
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.math.hypot

/**
 * The signature of the player: a still body of water, disturbed once.
 *
 * Every [RIPPLE_INTERVAL_MS] while a song is playing, one gentle wave leaves the
 * middle of the artwork and travels out across the whole screen, bending the
 * picture it passes over — the actual blurred artwork and its gradient, not a
 * circle drawn on top of them. It is meant to be almost missed: a few pixels of
 * refraction, no outline, no glow, no tint. The colours are the record's own
 * because nothing is added; the pixels are only *moved*.
 *
 * ## How it is made
 *
 * One AGSL `RuntimeShader` applied as the `renderEffect` of the background's own
 * graphics layer. The GPU re-samples the layer the app already rendered, so
 * nothing is captured to a bitmap and nothing is drawn twice. Only the uniforms
 * change per frame, and those are written inside the `graphicsLayer` block, which
 * Compose defers to the draw phase: the ripple never recomposes anything.
 *
 * ## What it costs when it is not running
 *
 * Nothing. The render effect is only attached while a wave is in flight (about
 * 1.8 s in every 10), so for the other ~82% of the time the background is the
 * plain layer it always was, with no offscreen pass.
 *
 * ## When it does not run
 *
 *  - below Android 13 (AGSL does not exist; the screen is simply still);
 *  - while nothing is playing, and while the app is not on screen — the wait is
 *    inside `repeatOnLifecycle(STARTED)`, so it is cancelled with the activity;
 *  - when the person has asked the system to remove animations
 *    (`ANIMATOR_DURATION_SCALE == 0`, which is what the accessibility switch
 *    sets), and in battery saver.
 */
@Composable
fun Modifier.waterRipple(
    /** Whether a wave should be sent every [RIPPLE_INTERVAL_MS]. */
    active: Boolean,
    /**
     * Where the wave starts, as a fraction of the layer's width and height.
     * The player passes the middle of the artwork.
     */
    origin: Offset = Offset(0.5f, 0.5f),
): Modifier {
    // AGSL is Android 13+. Anything older gets the modifier back untouched.
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return this
    return waterRippleApi33(active, origin)
}

@RequiresApi(Build.VERSION_CODES.TIRAMISU)
@Composable
private fun Modifier.waterRippleApi33(active: Boolean, origin: Offset): Modifier {
    val context = LocalContext.current
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    val density = LocalDensity.current

    // 0 → 1 across one wave. Read only inside the graphicsLayer block below.
    val wave = remember { Animatable(0f) }
    // Brought down to 0 for the moment it takes to stop a wave that is cut
    // short (playback paused mid-flight), so it dissolves instead of vanishing.
    val gain = remember { Animatable(1f) }
    val shader = remember { android.graphics.RuntimeShader(RIPPLE_AGSL) }
    val currentOrigin by rememberUpdatedState(origin)

    LaunchedEffect(active, lifecycle) {
        if (!active) return@LaunchedEffect
        try {
            // Suspends whenever the app leaves the screen and starts again, with
            // a fresh ten seconds, when it comes back.
            lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
                while (true) {
                    delay(RIPPLE_INTERVAL_MS)
                    // Asked again on every pass: the setting can change while
                    // the player is open, and a check made once would not see it.
                    if (!rippleAllowed(context)) continue
                    wave.snapTo(0f)
                    // Linear in time; the easing is in the shader, where the
                    // front and the dissipation each get their own curve.
                    wave.animateTo(1f, tween(RIPPLE_DURATION_MS, easing = LinearEasing))
                    wave.snapTo(0f)
                }
            }
        } finally {
            // Cut short — paused, backgrounded, or the player closed. If a wave
            // was in the air, let it die away rather than blink out.
            withContext(NonCancellable) {
                if (wave.value in 0.001f..0.999f) {
                    withTimeoutOrNull(FADE_OUT_MS + 200L) {
                        gain.animateTo(0f, tween(FADE_OUT_MS.toInt()))
                    }
                }
                wave.snapTo(0f)
                gain.snapTo(1f)
            }
        }
    }

    // A few dp of travel at the strongest point. Density-scaled so it looks the
    // same on every screen, and deliberately small: the effect is meant to be
    // noticed on the second or third time, not the first.
    val maxShiftPx = with(density) { MAX_SHIFT_DP.dp.toPx() }
    val waveLengthPx = with(density) { WAVELENGTH_DP.dp.toPx() }

    return this.graphicsLayer {
        val t = wave.value
        // At rest there is no effect at all — not a zero-strength one.
        if (t <= 0f || t >= 1f) {
            renderEffect = null
            return@graphicsLayer
        }
        val w = size.width
        val h = size.height
        val ox = w * currentOrigin.x
        val oy = h * currentOrigin.y
        // Far enough that the front has left the screen by the end, from
        // whichever corner is farthest from where it started.
        val reach = maxOf(
            hypot(ox, oy), hypot(w - ox, oy),
            hypot(ox, h - oy), hypot(w - ox, h - oy),
        )

        shader.setFloatUniform("resolution", w, h)
        shader.setFloatUniform("origin", ox, oy)
        shader.setFloatUniform("front", reach * frontEase(t) + waveLengthPx)
        shader.setFloatUniform("waveLength", waveLengthPx)
        shader.setFloatUniform("amplitude", maxShiftPx * amplitude(t) * gain.value)

        renderEffect = android.graphics.RenderEffect
            .createRuntimeShaderEffect(shader, "content")
            .asComposeRenderEffect()
    }
}

/** True when a wave may run right now. */
private fun rippleAllowed(context: Context): Boolean {
    // "Remove animations" in the accessibility settings sets the animator scale
    // to zero. The ripple is decoration; with that on there is none.
    val scale = Settings.Global.getFloat(
        context.contentResolver,
        Settings.Global.ANIMATOR_DURATION_SCALE,
        1f,
    )
    if (scale == 0f) return false
    // A moving full-screen shader is exactly what battery saver exists to stop.
    val power = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
    return power?.isPowerSaveMode != true
}

// The front leaves quickly and slows as it travels, like a disturbance losing
// its push. (0.2, 0.65, 0.3, 1.0) is an ease-out with a long tail.
private val FrontCurve = CubicBezierEasing(0.2f, 0.65f, 0.3f, 1f)

private fun frontEase(t: Float): Float = FrontCurve.transform(t)

/**
 * How strong the wave is at time [t].
 *
 * It rises over the first ~12% so that there is no edge at the start, and falls
 * away on a squared curve so that it has gone entirely — to exactly zero — at
 * the end, which is what lets the picture return without a jump.
 */
private fun amplitude(t: Float): Float {
    val rise = smooth((t / 0.12f).coerceIn(0f, 1f))
    val fall = (1f - t).let { it * it }
    return rise * fall
}

private fun smooth(x: Float): Float = x * x * (3f - 2f * x)

/** Time between waves, measured from the end of the last. */
const val RIPPLE_INTERVAL_MS = 10_000L

/** One wave, front to last trace. Inside the 1.5–2 s the effect is meant to take. */
const val RIPPLE_DURATION_MS = 1_800

private const val FADE_OUT_MS = 220L
private const val MAX_SHIFT_DP = 5f
private const val WAVELENGTH_DP = 90f

/**
 * The displacement program.
 *
 * `content` is the layer's own rendering. For every pixel this asks "which pixel
 * of the original should I be showing here?" and answers with one a few pixels
 * towards or away from the centre of the wave. A pixel is never darkened,
 * brightened or recoloured; the picture is only re-sampled, so the record's
 * colours are exactly what they were.
 *
 * The disturbance is a short train of crests that trails behind a moving front.
 * Its envelope is a wide Gaussian and the crests inside it are a sine, so there
 * is no ring edge anywhere: the displacement is smooth in space, and the
 * outward push and the inward pull alternate, which is what reads as water
 * rather than as a shockwave.
 */
private const val RIPPLE_AGSL = """
uniform shader content;
uniform float2 resolution;
uniform float2 origin;
uniform float front;       // distance the leading edge has reached, px
uniform float waveLength;  // px, crest to crest
uniform float amplitude;   // px, at the strongest point

half4 main(float2 p) {
    float2 d = p - origin;
    float r = length(d);

    // Behind the front is positive. Nothing ahead of it has been touched yet.
    float behind = front - r;

    // Soft start at the leading edge, so there is no visible rim.
    float lead = smoothstep(0.0, waveLength * 0.6, behind);

    // A wide trailing envelope: the crests fade away behind the front instead
    // of ending abruptly.
    float x = behind / (waveLength * 1.6);
    float envelope = exp(-x * x) * lead;

    // Two or three crests under that envelope.
    float crest = sin(behind / waveLength * 6.2831853);

    // Push along the line from the centre. Guarded at r = 0.
    float2 dir = d / max(r, 0.0001);
    float2 shift = dir * crest * envelope * amplitude;

    // Stay inside the layer: the edges carry on rather than turning
    // transparent.
    float2 q = clamp(p - shift, float2(0.5), resolution - float2(0.5));
    return content.eval(q);
}
"""
